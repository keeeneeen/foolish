<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:type" content="website">
    <meta property="og:title" content="59th 獅子児祭 Diverge">
    <meta property="og:description" content="2024年度獅子児祭 9/15,16 開催!">
    <meta property="og:site_name" content="SHISHIJI FES">
    <meta property="og:image" content="https://pbs.twimg.com/profile_images/1402955393194594308/a5pHbQKZ_400x400.jpg">
    <meta property="og:locale" content="ja">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="@shishijifes">
    <meta name="twitter:creator" content="@shishijifes">
    <meta name="twitter:title" content="59th 獅子児祭 Diverge">
    <meta name="twitter:description" content="2024年度獅子児祭 9/15,16 開催！">
    <meta name="twitter:image" content="https://pbs.twimg.com/profile_images/1402955393194594308/a5pHbQKZ_400x400.jpg">
    <meta name="theme-color" content="rgb(21, 32, 43)" id="theme-meta">
    <title>59th 獅子児祭 Diverge</title>
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/index.css">
    <style>
        *{
        margin: 0;
        padding: 0;
        font-family: "zen-kaku-gothic-new", sans-serif;
        }
        </style>
    <link rel="preload" href="/the-theme-kotei3/NotosansJP.ttf" as="font" type="font/ttf">
    <script>
        (function(d) {
          var config = {
            kitId: 'gun5tqp',
            scriptTimeout: 3000,
            async: true
          },
          h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
        })(document);
    </script>
</head>
<body style="background-color: rgb(21, 32, 43); min-height: 100vh;" class="background-range">
    <div class="info" style="width:90vw; max-width: 800px; margin-left:auto; margin-right: auto;">
        <p class="headline3" style="margin-bottom: 5vh;margin-top: 3vh;">「Webアプリ」について</p>
        <p class="text">
            今年の文化祭では例年のパンフレットをデジタル化した、独自の「Webアプリ」を制作しました。<br><br>

            従来のパンフレットの機能はもちろん、その他にもパンフレットにはできない便利な機能や、より文化祭が面白くなる「スタンプラリー」、全来場者でポイント数を競う「ランキングシステム」なども搭載しています。<br><br>
            
            「Webアプリ」は、ご来場者様ご自身のデバイスのブラウザアプリ（Safari, Chromeなど）でご利用可能です。使用方法は当日の会場で実行委員がご説明いたします。<br><br>
            
            新たな獅子児祭をお楽しみに！<br><br>
            
            ※「Webアプリ」のご利用にはインターネット環境が必要です。通信料はご来場者様のご負担となります。<br>
            ※当日の会場では獅子児祭の大まかな情報を確認できる紙のパンフレットもご用意しております。 
        </p>
    </div>
</body>