<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:type" content="website">
    <meta property="og:title" content="59th 獅子児祭 Diverge">
    <meta property="og:description" content="2024年度獅子児祭 9/15,16 開催!">
    <meta property="og:site_name" content="SHISHIJI FES">
    <meta property="og:image" content="https://pbs.twimg.com/profile_images/1402955393194594308/a5pHbQKZ_400x400.jpg">
    <meta property="og:locale" content="ja">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="@shishijifes">
    <meta name="twitter:creator" content="@shishijifes">
    <meta name="twitter:title" content="59th 獅子児祭 Diverge">
    <meta name="twitter:description" content="2024年度獅子児祭 9/15,16 開催！">
    <meta name="twitter:image" content="https://pbs.twimg.com/profile_images/1402955393194594308/a5pHbQKZ_400x400.jpg">
    <meta name="theme-color" content="rgb(21, 32, 43)" id="theme-meta">
    <title>59th 獅子児祭 Diverge</title>
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/index.css">
    <style>
        *{
        margin: 0;
        padding: 0;
        font-family: "zen-kaku-gothic-new", sans-serif;
        }
        </style>
    <link rel="preload" href="/the-theme-kotei3/NotosansJP.ttf" as="font" type="font/ttf">
    <script>
        (function(d) {
          var config = {
            kitId: 'gun5tqp',
            scriptTimeout: 3000,
            async: true
          },
          h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
        })(document);
    </script>
</head>



<body style="background-color: rgb(21, 32, 43);width: 100vw;overflow-x: hidden;padding-bottom: 50px;">
    
<div class="background-range">
<div id="toppage" style="height: 100vh;">
        <img src="<?php echo get_template_directory_uri(); ?>/images/shishiji-fes.png" alt="" style="margin-top: 0vh;">
        <img src="<?php echo get_template_directory_uri(); ?>/images/2024.png" alt="" style="margin-bottom: 5vh;">
        <div class="info" style="margin-top: 2vh;">
        <div style="display: flex;">
            <p class="headline2-5">9/15</p>
            <p class="text" style="padding-top: 14px;">&thinsp;(日)</p>
        </div>
        <div style="display: flex;">
            <p class="headline2-5">9/16</p>
            <p class="text" style="padding-top: 14px;">&thinsp;(月)</p>
        </div>
        


        <p class="headline3">9:00 - 16:00</p>

        <label onclick="ShowAccess()" class="btn_23" style="cursor: pointer; margin-top: 3vh;"><span style="margin-left: 25px;">Access&emsp;&gt;</span></label>
        </div>







        <div id="sns-itiran" style="margin-top: 10vh;">
            <a href="https://www.instagram.com/shishijifes_official/" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/insw.png" alt=""></a>
            <a href="https://twitter.com/shishijifes" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/twiw.png" alt=""></a>
            <a href="https://www.youtube.com/@shishijifes./shorts" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/youw.png" alt=""></a>
            <a href="https://www.tiktok.com/@shishijifes_official" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/tikw.png" alt=""></a>
        </div>
    </div>

    <div class="funny-pare">
        <a class="funny-place" id="subgod" target="_blank">
            
        </a>
        <a class="funny-place" id="subsubgod" target="_blank">
            
        </a>
    </div>

    <div id="webapp-introduce-headline" class="info" style="margin-top: 6vh; width: min(85vw,380px);margin-left: auto;margin-right: auto;padding: 15px;padding-bottom: 3vh; background-color: #2c5f6c;">
    <p class="headline4" style="margin-top: 3vh;">各団体の情報はこちら</p>
        <a href="eventt/" target="_blank" class="btn_23 to-org" style="cursor: pointer; margin-top: 3vh;"><span style="margin-left: 25px;">イベント一覧&emsp;＞</span></a>
        <a href="org/" target="_blank" class="btn_23 to-org" style="cursor: pointer; margin-top: 2vh;"><span style="margin-left: 25px;">展示団体一覧&emsp;＞</span></a>
        <p class="headline4" style="margin-top: 7vh;">進化したデジタルパンフレット<br>「Webアプリ」が登場!</p>
        <a href="webapp/" target="_blank" class="btn_23 to-org" style="cursor: pointer; margin-top: 3vh;"><span style="margin-left: 25px;">詳細&emsp;＞</span></a>
    </div>
    </div>

    <div id="introduce" class="info" style="width: 90vw;max-width: 600px;;margin-left: auto;margin-right: auto;margin-top: 10vh;">
        <p class="headline3" style="margin-left: auto;margin-right: auto;">ごあいさつ</p>
        <p style="margin-right: auto;margin-top: 2vh;">獅子児祭実行委員会委員長 山本耕大</p>
        <p style="margin-top: 3vh;">&emsp;こんにちは！今年も獅子児祭の日がやってきました。まずは、自分が委員長になってから一年近く活動してきた実行委員のみんなに感謝を申し上げます。<br><br>
            &emsp;僕が実行委員長をやろうと思ったきっかけの一つは、様々な才能がこの学校にあると思ったことです。プログラミングができる人、イラストが描ける人、動画制作やPAができる人、それからモチベーターとして周りの作業効率を何倍にも上げられる人、心を鬼にして生徒同士で指示できる人。ここに男子の特性「見通しの甘さ」が加わることで、どんな無茶な理想でもきっとできるとチャレンジすることができる。これこそが男子校の良いところなんだろうと気づき、こんなチャレンジができる機会はそうそうないだろうと思って実行委員長に名乗りを上げました。<br><br>
            &emsp;今年のテーマは”Diverge” 日本語で分岐を意味します。才能たちが文化祭の中で様々なことにチャレンジすることで自分の得意・楽しいことを見つけ、目の前にある人生の分岐点を自分らしく選んで進んでほしいと願っています。<br><br>
            &emsp;さて、今年の文化祭では、紙のパンフレットに変わり生徒自作のwebアプリを運用します。ただのデジタルパンフレットとしてではなく、ミッションの機能やイベントのリアルタイムスケジュール表示、オンライン投票機能など、様々な機能を搭載しており、間違いなく唯一無二の体験をしていただけることでしょう！<br>
            &emsp;また、今年はアリーナ(体育館)が最高のライブ会場となります。前方のステージは、実行委員屈指の精鋭部隊であるIT部により最高の演出がなされ、有志のダンス・バンド団体が披露します。そしてアリーナ後方には販売部門による飲料販売が行われ、お客さんは飲み物を手にしながら盛り上がることができ、これもまた格別の楽しさを体験してもらえるでしょう！<br>
            &emsp;ジェットコースターや物理部の「セタゴラスイッチ」などTVでも取り上げられた有名企画はもちろん、有志展示や装飾など、生徒全員が全力で準備したものを是非是非お楽しみください。
        </p>
    </div>




</body>
<script>
    function ShowAccess(){
        document.body.innerHTML = `
        <div class="background-range">
<div class="info" style="width:90vw; margin-left:5vw;">
    <div style="position: absolute;top: 0;left: 0;"><p class="headline3" onclick="ShowTOP()" style="cursor:pointer;"> &lt; <u>Top</u></p></div>
    <p class="headline2" style="margin-top: 3vh;">Access</p>
    <p class="text" style="margin-bottom: 5vh;">アクセス</p>
    <p class="headline3">世田谷学園 中学校 高等学校</p><br>
    <p class="text" style="margin-bottom: 5vh;">
        〒154-0005 東京都世田谷区三宿1-16-31<br>
        &thinsp;TEL : 03-3411-8661&emsp;FAX : 03-3487-9113<br>
        ■東急田園都市線・世田谷線／三軒茶屋駅 北口Ｂ 徒歩約10分<br>
        ■小田急線・京王井の頭線／下北沢駅 徒歩約25分<br>
        ■京王井の頭線／池ノ上駅 徒歩約20分<br>
        ■バス／三宿停留所下車 徒歩約5分<br>
    </p>
    <img src="<?php echo get_template_directory_uri(); ?>/images/accessmap.jpg" id="touchable">
</div>
</div>
    `;
    window.scrollTo(0, 0);
    }
</script>

<script>
    function ShowTOP(){
        document.body.innerHTML = `
        
<div class="background-range">
<div id="toppage" style="height: 100vh;">
        <img src="<?php echo get_template_directory_uri(); ?>/images/shishiji-fes.png" alt="" style="margin-top: 0vh;">
        <img src="<?php echo get_template_directory_uri(); ?>/images/2024.png" alt="" style="margin-bottom: 5vh;">
        <div class="info" style="margin-top: 2vh;">
        <div style="display: flex;">
            <p class="headline2-5">9/15</p>
            <p class="text" style="padding-top: 14px;">&thinsp;(日)</p>
        </div>
        <div style="display: flex;">
            <p class="headline2-5">9/16</p>
            <p class="text" style="padding-top: 14px;">&thinsp;(月)</p>
        </div>
        


        <p class="headline3">9:00 - 16:00</p>

        <label onclick="ShowAccess()" class="btn_23" style="cursor: pointer; margin-top: 3vh;"><span style="margin-left: 25px;">Access&emsp;&gt;</span></label>
        </div>







        <div id="sns-itiran" style="margin-top: 10vh;">
            <a href="https://www.instagram.com/shishijifes_official/" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/insw.png" alt=""></a>
            <a href="https://twitter.com/shishijifes" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/twiw.png" alt=""></a>
            <a href="https://www.youtube.com/@shishijifes./shorts" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/youw.png" alt=""></a>
            <a href="https://www.tiktok.com/@shishijifes_official" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/tikw.png" alt=""></a>
        </div>
    </div>

    <div class="funny-pare">
        <a class="funny-place" id="subgod" target="_blank">
            
        </a>
        <a class="funny-place" id="subsubgod" target="_blank">
            
        </a>
    </div>

    <div id="webapp-introduce-headline" class="info" style="margin-top: 6vh; width: min(85vw,380px);margin-left: auto;margin-right: auto;padding: 15px;padding-bottom: 3vh; background-color: #2c5f6c;">
    <p class="headline4" style="margin-top: 3vh;">各団体の情報はこちら</p>
        <a href="eventt/" target="_blank" class="btn_23 to-org" style="cursor: pointer; margin-top: 3vh;"><span style="margin-left: 25px;">イベント一覧&emsp;＞</span></a>
        <a href="org/" target="_blank" class="btn_23 to-org" style="cursor: pointer; margin-top: 2vh;"><span style="margin-left: 25px;">展示団体一覧&emsp;＞</span></a>
        <p class="headline4" style="margin-top: 7vh;">進化したデジタルパンフレット<br>「Webアプリ」が登場!</p>
        <a href="webapp/" target="_blank" class="btn_23 to-org" style="cursor: pointer; margin-top: 3vh;"><span style="margin-left: 25px;">詳細&emsp;＞</span></a>
    </div>
    </div>

    <div id="introduce" class="info" style="width: 90vw;max-width: 600px;;margin-left: auto;margin-right: auto;margin-top: 10vh;">
        <p class="headline3" style="margin-left: auto;margin-right: auto;">ごあいさつ</p>
        <p style="margin-right: auto;margin-top: 2vh;">獅子児祭実行委員会委員長 山本耕大</p>
        <p style="margin-top: 3vh;">&emsp;こんにちは！今年も獅子児祭の日がやってきました。まずは、自分が委員長になってから一年近く活動してきた実行委員のみんなに感謝を申し上げます。<br><br>
            &emsp;僕が実行委員長をやろうと思ったきっかけの一つは、様々な才能がこの学校にあると思ったことです。プログラミングができる人、イラストが描ける人、動画制作やPAができる人、それからモチベーターとして周りの作業効率を何倍にも上げられる人、心を鬼にして生徒同士で指示できる人。ここに男子の特性「見通しの甘さ」が加わることで、どんな無茶な理想でもきっとできるとチャレンジすることができる。これこそが男子校の良いところなんだろうと気づき、こんなチャレンジができる機会はそうそうないだろうと思って実行委員長に名乗りを上げました。<br><br>
            &emsp;今年のテーマは”Diverge” 日本語で分岐を意味します。才能たちが文化祭の中で様々なことにチャレンジすることで自分の得意・楽しいことを見つけ、目の前にある人生の分岐点を自分らしく選んで進んでほしいと願っています。<br><br>
            &emsp;さて、今年の文化祭では、紙のパンフレットに変わり生徒自作のwebアプリを運用します。ただのデジタルパンフレットとしてではなく、ミッションの機能やイベントのリアルタイムスケジュール表示、オンライン投票機能など、様々な機能を搭載しており、間違いなく唯一無二の体験をしていただけることでしょう！<br>
            &emsp;また、今年はアリーナ(体育館)が最高のライブ会場となります。前方のステージは、実行委員屈指の精鋭部隊であるIT部により最高の演出がなされ、有志のダンス・バンド団体が披露します。そしてアリーナ後方には販売部門による飲料販売が行われ、お客さんは飲み物を手にしながら盛り上がることができ、これもまた格別の楽しさを体験してもらえるでしょう！<br>
            &emsp;ジェットコースターや物理部の「セタゴラスイッチ」などTVでも取り上げられた有名企画はもちろん、有志展示や装飾など、生徒全員が全力で準備したものを是非是非お楽しみください。
        </p>
    </div>


    `;
    window.scrollTo(0, 0);
    chhumanbeing();
    }
</script>
<script>
    const adData = [
        {
            img: "<?php echo get_template_directory_uri(); ?>/funnies/tfn-1.png",
            url: "https://www.otsuka-shokai.co.jp/",
            alt: "大塚商会",
        },
        {
            img: "<?php echo get_template_directory_uri(); ?>/funnies/tfn-2.png",
            url: "https://www.tou-ko.co.jp",
            alt: "株式会社東光社",
        },
        {
            img: "<?php echo get_template_directory_uri(); ?>/funnies/tfn-3.png",
            url: "https://nbm-kk.co.jp/",
            alt: "日本ビルメンテナンス株式会社",
        },
        {
            img: "<?php echo get_template_directory_uri(); ?>/funnies/tfn-4.png",
            url: "https://www.compass-dc.jp/",
            alt: "コンパスメディカルグループ 医療法人社団コンパス",
        },
        {
            img: "<?php echo get_template_directory_uri(); ?>/funnies/tfn-5.png",
            url: "https://www.oceanbluebird.com/",
            alt: "Ocean Blue Bird",
        },
        {
            img: "<?php echo get_template_directory_uri(); ?>/funnies/tfn-6.png",
            url: "https://ksg.co.jp/",
            alt: "教育産業株式会社",
        },
        {
            img: "<?php echo get_template_directory_uri(); ?>/funnies/tfn-7.png",
            url: "https://www.tousyu.co.jp/",
            alt: "株式会社東秀開発",
        },




    ];
    const interval = (5)*1000;
    
    function suffle(arr){
        for (var i = arr.length - 1; i > 0; i--){
            const j = Math.floor(Math.random() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]];
        }
        return arr;
    }
    
    const _adData = suffle(adData);
    var lastImgElms = {
        ue: null,
        sita: null,
    };
    var idx = -1;

    const chhuman = (id, dotti) => {
        idx >= _adData.length-1 ? idx = -1 : void(0);
        
        const n = ++idx;
        const imgElm = document.createElement("img");
    
        imgElm.setAttribute("src", _adData[n].img);
        imgElm.classList.add("hello_youtube");
        document.getElementById(id).setAttribute("href", _adData[n].url);
    
        document.getElementById(id).appendChild(imgElm);
    
        if (lastImgElms[dotti]){
            +function(_lelm){
                _lelm.classList.add("see_you_next_time");
                setTimeout(()=>_lelm.remove(), 1000);
            }(lastImgElms[dotti]);
        }
        lastImgElms[dotti] = imgElm;
    }
    
    const chman = ()=>{
        chhuman("subgod", "ue");
    };
    const chwoman = () => {
        chhuman("subsubgod", "sita");
    };
    const chhumanbeing = () => {
        chman();
        chwoman();
    };
    
    chhumanbeing();
    setInterval(chhumanbeing, interval);
        </script>
</html>
