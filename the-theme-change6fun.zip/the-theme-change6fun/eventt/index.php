<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:type" content="website">
    <meta property="og:title" content="59th 獅子児祭 Diverge">
    <meta property="og:description" content="2024年度獅子児祭 9/15,16 開催!">
    <meta property="og:site_name" content="SHISHIJI FES">
    <meta property="og:image" content="https://pbs.twimg.com/profile_images/1402955393194594308/a5pHbQKZ_400x400.jpg">
    <meta property="og:locale" content="ja">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="@shishijifes">
    <meta name="twitter:creator" content="@shishijifes">
    <meta name="twitter:title" content="59th 獅子児祭 Diverge">
    <meta name="twitter:description" content="2024年度獅子児祭 9/15,16 開催！">
    <meta name="twitter:image" content="https://pbs.twimg.com/profile_images/1402955393194594308/a5pHbQKZ_400x400.jpg">
    <meta name="theme-color" content="rgb(21, 32, 43)" id="theme-meta">
    <title>59th 獅子児祭 Diverge</title>
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/index.css">
    <style>
        *{
        margin: 0;
        padding: 0;
        font-family: "zen-kaku-gothic-new", sans-serif;
        }
        </style>
    <link rel="preload" href="/the-theme-kotei3/NotosansJP.ttf" as="font" type="font/ttf">
    <script>
        (function(d) {
          var config = {
            kitId: 'gun5tqp',
            scriptTimeout: 3000,
            async: true
          },
          h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
        })(document);
    </script>
</head>
<body class="background-range" style="background-color: rgb(21, 32, 43);width: 100vw;max-width: 1000px;min-height: 97vh;overflow-x: hidden;padding-bottom: 2vh;margin-left: auto;margin-right: auto;position: relative;">


        <div class="info" style="width: min(85vw,380px);margin-left: auto;margin-right: auto;padding: 15px;padding-bottom: 3vh;">
            <p class="headline2-5" style="margin-top: 3vh; margin-bottom: 3vh;">イベント一覧</p>
            <label onclick="ShowBand()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>SETA ROCK（バンド）</span></label>
            <label onclick="ShowDance()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>ダンス</span></label>
            <label onclick="ShowFesCon()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>吹奏楽部 Festival Concert 2024</span></label>
            <label onclick="ShowChoFes()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>CHORUS FESTIVAL 2024</span></label>
            <label onclick="ShowKasyo()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>先生&生徒歌唱大会</span></label>
            <label onclick="ShowMuscle()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>SETAGAKU筋肉自慢</span></label>
            <label onclick="ShowQuiz()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>クイズ</span></label>
            <label onclick="ShowS1()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>S1グランプリ（お笑いライブ）</span></label>
            <label onclick="ShowClassic()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>教員によるクラシックコンサート</span></label>
            <label onclick="ShowTorowa()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>トロワ・クール ミニコンサート</span></label>
            <label onclick="ShowPiano()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>獅子児ピアノの森</span></label>
            <label onclick="ShowHikigatari()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>弾き語りライブ</span></label>
            <label onclick="ShowBakeEX()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>この素晴らしい学園祭に爆泡を（化学部）</span></label>
            <label onclick="ShowGekidan()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>劇団獅子〜演劇・コント〜</span></label>
            <label onclick="ShowEiken()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>映研ロードショー</span></label>
            <label onclick="ShowPresen()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>みんなでプレゼン!（政治経済研究部）</span></label>
        </div>

</body>
<script>
  var main_scroll_top = 0;
  // 戻すやつ
  function ShowEventTop(){
    document.body.innerHTML = `
        <div class="info" style="width: min(85vw,380px);margin-left: auto;margin-right: auto;padding: 15px;padding-bottom: 3vh;">
            <p class="headline2-5" style="margin-top: 3vh; margin-bottom: 3vh;">イベント一覧</p>
            <label onclick="ShowBand()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>SETA ROCK（バンド）</span></label>
            <label onclick="ShowDance()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>ダンス</span></label>
            <label onclick="ShowFesCon()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>吹奏楽部 Festival Concert 2024</span></label>
            <label onclick="ShowChoFes()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>CHORUS FESTIVAL 2024</span></label>
            <label onclick="ShowKasyo()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>先生&生徒歌唱大会</span></label>
            <label onclick="ShowMuscle()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>SETAGAKU筋肉自慢</span></label>
            <label onclick="ShowQuiz()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>クイズ</span></label>
            <label onclick="ShowS1()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>S1グランプリ（お笑いライブ）</span></label>
            <label onclick="ShowClassic()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>教員によるクラシックコンサート</span></label>
            <label onclick="ShowTorowa()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>トロワ・クール ミニコンサート</span></label>
            <label onclick="ShowPiano()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>獅子児ピアノの森</span></label>
            <label onclick="ShowHikigatari()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>弾き語りライブ</span></label>
            <label onclick="ShowBakeEX()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>この素晴らしい学園祭に爆泡を（化学部）</span></label>
            <label onclick="ShowGekidan()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>劇団獅子〜演劇・コント〜</span></label>
            <label onclick="ShowEiken()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>映研ロードショー</span></label>
            <label onclick="ShowPresen()" class="btn_23 to-org" style="cursor: pointer; margin-top: 1vh;"><span>みんなでプレゼン!（政治経済研究部）</span></label>
        </div>
  `;
  window.scrollTo(0, main_scroll_top);
  };

  // 変えるやつ
  function ShowBand(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
        <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
            <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;バンド</p></div>
            <p style="margin-top: 8vh;" class="headline2-5">SETA ROCK（バンド）</p>
            <p style="margin-top: 2vh;" class="text">開催場所: アリーナ（体育館）</p>
            <div style="display: flex;margin-top: 1vh;margin-bottom: 5vh;">
              <p class="text">開催時間:&nbsp;</p>
              <p class="text">15日(日)&emsp;<br><br>16日(月)&emsp;</p>
              <p class="text">前半 9:30 ~ 11:00<br>後半 11:15 ~ 12:45<br>前半 12:15 ~ 13:45<br>後半 14:00 ~ 15:30</p>
            </div>
            <div class="event-list">
              <p class="text" style="margin-top: 2vh;">バンド団体一覧（出演順）</p>
              <p class="text" style="margin-top: 2vh;margin-bottom: 2vh;">・前半グループ</p>
              <div id="band-zenhan" class="band-zenhankouhan">

              </div>
              <p class="text" style="margin-top: 4vh;margin-bottom: 2vh;">・後半グループ</p>
              <div id="band-kouhan" class="band-zenhankouhan">

              </div>
            </div>
        </div>
  `;

  const band_zenhan_data = [
    {
        "name":"AIAN'S",
    },
    {
        "name":"HEKI",
    },
    {
        "name":"背骨軟骨",
    },
    {
        "name":"ラムダ",
    },
    {
        "name":"険悪",
    },
    {
        "name":"TーLUSHES",
    },
    {
        "name":"ベジタリアンズ",
    },
    {
        "name":"くいんてっと",
    },

    // {
    //     "name":"",
    // },
];

const band_kouhan_data = [
    {
        "name":"Blue mates",
    },
    {
        "name":"へっじほっぐ！！",
    },
    {
        "name":"バレー部バンド！？",
    },
    {
        "name":"ポジニ来ズ",
    },
    {
        "name":"OCTED",
    },
    {
        "name":"ごっつあんクラブ",
    },

    
    // {
    //     "name":"",
    // },
];

for (var n_zenhan = 0; n_zenhan < Object.keys(band_zenhan_data).length; n_zenhan++){

document.getElementById("band-zenhan").innerHTML += 

`<div><p>`
 + band_zenhan_data[n_zenhan]["name"]
 + `</p></div>`;

};

for (var n_kouhan = 0; n_kouhan < Object.keys(band_kouhan_data).length; n_kouhan++){

document.getElementById("band-kouhan").innerHTML += 

`<div><p>`
 + band_kouhan_data[n_kouhan]["name"]
 + `</p></div>`;

};
  window.scrollTo(0, 0);
  };



  function ShowDance(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
        <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
            <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;ダンス</p></div>
            <p style="margin-top: 8vh;" class="headline2-5">THE ARENA DANCE</p>
            <p class="text">全てのダンス団体が出演します。バンドステージと並ぶメインイベントの1つです！</p>
            <p style="margin-top: 2vh;" class="text">開催場所: アリーナ（体育館）</p>
            <div style="display: flex;margin-top: 1vh;">
              <p class="text">開催時間:&nbsp;</p>
              <p class="text">15日(日)&emsp;<br><br>16日(月)&emsp;</p>
              <p class="text">前半 13:15 ~ 14:15<br>後半 14:30 ~ 15:30<br>前半 9:30 ~ 10:30<br>後半 10:45 ~ 11:45</p>
            </div>
            <p style="margin-top: 3vh;" class="headline2-5">ダンスフリーステージ</p>
            <p class="text">THE ARENA DANCE出演団体から、希望団体が出演します。誰が出るかは当日までお楽しみに！</p>
            <p style="margin-top: 2vh;" class="text">開催場所: 武道場</p>
            <div style="display: flex;margin-top: 1vh;margin-bottom: 5vh">
              <p class="text">開催時間:&nbsp;</p>
              <p class="text">15日(日)&emsp;<br>16日(月)&emsp;</p>
              <p class="text">12:30 ~ 13:00<br>13:00 ~ 13:30</p>
            </div>
            <div class="event-list">
              <p class="text" style="margin-top: 2vh;">ダンス団体一覧（THE ARENA DANCE 出演順）</p>
              <p class="text" style="margin-top: 2vh;margin-bottom: 2vh;">・前半グループ</p>
              <div id="dance-zenhan" class="dance-zenhankouhan">

              </div>
              <p class="text" style="margin-top: 4vh;margin-bottom: 2vh;">・後半グループ</p>
              <div id="dance-kouhan" class="dance-zenhankouhan">

              </div>
            </div>
        </div>
  `;

  const dance_zenhan_data = [
    {
        "name":"stylish cowards",
    },
    {
        "name":"獅子児祭ARASHI",
    },
    {
        "name":"じゅに坂",
    },
    {
        "name":"あっぷるぱい",
    },
    {
        "name":"踊るバレー部",
    },
    {
        "name":"LADY:FIRST",
    },
    {
        "name":"Da-iZU",
    },
    {
        "name":"ジョージーンズ",
    },

    // {
    //     "name":"",
    // },
];

const dance_kouhan_data = [
    {
        "name":"once",
    },
    {
        "name":"スンドゥブ豆腐",
    },
    {
        "name":"リアルセタボーイズ",
    },
    {
        "name":"XⅡCBOYZ",
    },
    {
        "name":"2代目仏教少年団",
    },
    {
        "name":"SetarayKids",
    },
    {
        "name":"Plaisir",
    },
    {
        "name":"Arise",
    },

    
    // {
    //     "name":"",
    // },
];

for (var n_zenhan = 0; n_zenhan < Object.keys(dance_zenhan_data).length; n_zenhan++){

document.getElementById("dance-zenhan").innerHTML += 

`<div><p>`
 + dance_zenhan_data[n_zenhan]["name"]
 + `</p></div>`;

};

for (var n_kouhan = 0; n_kouhan < Object.keys(dance_kouhan_data).length; n_kouhan++){

document.getElementById("dance-kouhan").innerHTML += 

`<div><p>`
 + dance_kouhan_data[n_kouhan]["name"]
 + `</p></div>`;

};
  window.scrollTo(0, 0);
  };

  function ShowFesCon(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;吹奏楽部 Festival Concert 2024</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">吹奏楽部 Festival Concert 2024</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 修道館ホール</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">15日(日)&emsp;<br>16日(月)&emsp;</p>
      <p class="text">13:30 ~ 15:30<br>10:00 ~ 12:00</p>
    </div>
    <p style="margin-top: 4vh;" class="text">
      今年は辰年ということで迫力あるドラゴンの曲を演奏します！<br>
      他にもJ-popや大河テーマ曲等、心踊るコンサートをぜひ聴きに来てください♪
    </p>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowChoFes(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;CHORUS FESTIVAL 2024</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">CHORUS FESTIVAL 2024</p>
    <p class="text">2年生合唱コンクール</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 武道場</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">15日(日)&emsp;</p>
      <p class="text">10:00 ~ 12:00</p>
    </div>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowKasyo(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;先生&生徒歌唱大会</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">先生&生徒歌唱大会</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 武道場</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">15日(日)&emsp;</p>
      <p class="text">13:30 ~ 14:00</p>
    </div>
    <p style="margin-top: 4vh;" class="text">
      生徒と先生それぞれが練習してきた曲を歌います。<br>
      歌の先生と言えば.....という方を2人招待させて頂きました。<br>
      生徒と先生のデュエットもあるのでお楽しみに！<br><br>
      
    
      第ゼロ感<br>
      栄光の架橋<br>
      スパークル<br>
      ギラギラ<br>
      怪獣の花唄<br>
      スターマイン
    </p>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowMuscle(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;SETAGAKU筋肉自慢</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">SETAGAKU筋肉自慢</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 武道場</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">16日(月)&emsp;</p>
      <p class="text">12:00 ~ 12:30</p>
    </div>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowQuiz(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;クイズ</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">クイズ世田学生は受験生より賢いの？</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 武道場</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">15日(日)&emsp;</p>
      <p class="text">14:45 ~ 15:15</p>
    </div>
    <p style="margin-top: 4vh;" class="text">
      受験生と世田学生でクイズ対決をします！<br>
      世田学の過去問や、さまざまな分野から出題予定なので是非来てみてください！
    </p>
    <p style="margin-top: 3vh;" class="headline2-5">クイズ先生はもちろん生徒より賢いよね？</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 武道場</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">16日(月)&emsp;</p>
      <p class="text">11:00 ~ 11:30</p>
    </div>
    <p style="margin-top: 4vh;" class="text">
      先生と生徒でガチ対決をします！<br>
      トレンドから入試の過去問まで幅広く出題するのでぜひ一緒に考えてみてください！<br>
      ご来場お待ちしてます！
    </p>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowS1(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;S1グランプリ（お笑いライブ）</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">S1グランプリ（お笑いライブ）</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 放光館ホール</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">15日(日)&emsp;<br>16日(月)&emsp;</p>
      <p class="text">14:00 ~ 15:15<br>11:00 ~ 12:00</p>
    </div>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowClassic(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;教員によるクラシックコンサート</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">教員によるクラシックコンサート</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 放光館ホール</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">15日(日)&emsp;</p>
      <p class="text">9:30 ~ 10:30</p>
    </div>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowTorowa(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;トロワ・クール ミニコンサート</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">トロワ・クール ミニコンサート</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 放光館ホール</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">16日(月)&emsp;</p>
      <p class="text">9:45 ~ 10:45</p>
    </div>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowPiano(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;獅子児ピアノの森</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">獅子児ピアノの森</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 放光館ホール</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">15日(日)&emsp;</p>
      <p class="text">11:00 ~ 12:00</p>
    </div>
    <p style="margin-top: 4vh;" class="text">
      興味があったら是非入ってみてくださいな。<br>
      素敵な演奏を届けます。
    </p>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowHikigatari(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;弾き語りライブ</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">弾き語りライブ</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 放光館ホール</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">15日(日)&emsp;<br>16日(月)&emsp;</p>
      <p class="text">13:15 ~ 13:45<br>13:45 ~ 14:30</p>
    </div>
    <p style="margin-top: 4vh;" class="text">
      竹原ピストルが大好きです。<br>
      竹原ピストルのカバーと今は解散してしまった竹原ピストル（ボーカル、アコースティックギター）と濱埜宏哉（鍵盤、コーラス）による二人組ユニットである野狐禅のカバーを2人でそれぞれ半々で披露します。      
    </p>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowBakeEX(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;この素晴らしい学園祭に爆泡を（化学部）</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">この素晴らしい学園祭に爆泡を（化学部）</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 生徒玄関前</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">15日(日)&emsp;<br>16日(月)&emsp;</p>
      <p class="text">11:30 ~ 12:00<br>11:30 ~ 12:00</p>
    </div>
    <p style="margin-top: 4vh;" class="text">
      化学部が、最大規模の実験を行います！！      
    </p>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowGekidan(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;劇団獅子〜演劇・コント〜</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">劇団獅子〜演劇・コント〜</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 放光館ホール</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">16日(月)&emsp;</p>
      <p class="text">13:00 ~ 13:30</p>
    </div>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowEiken(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;映研ロードショー</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">映研ロードショー</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 放光館ホール</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">15日(日)&emsp;<br><br>16日(月)&emsp;</p>
      <p class="text">12:15 ~ 12:45<br>15:30 ~ 15:45<br>12:15 ~ 12:45<br>14:45 ~ 15:15</p>
    </div>
  </div>
  `;
  window.scrollTo(0, 0);
  };

  function ShowPresen(){
    main_scroll_top = window.scrollY;
    document.body.innerHTML = `
  <div class="event" style="width: min(90vw,450px);margin-left: auto;margin-right: auto;padding: 5px;padding-bottom: 3vh;">
    <div style="position: absolute;top: 5px;left: 10px;display: flex;"><p class="text" onclick="ShowEventTop()" style="cursor:pointer;"><u>イベント</u></p><p>&nbsp;&gt;&nbsp;みんなでプレゼン!（政治経済研究部）</p></div>
    <p style="margin-top: 8vh;" class="headline2-5">みんなでプレゼン!（政治経済研究部）</p>
    <p style="margin-top: 2vh;" class="text">開催場所: 修道館ホール</p>
    <div style="display: flex;margin-top: 1vh;">
      <p class="text">開催時間:&nbsp;</p>
      <p class="text">16日(月)&emsp;</p>
      <p class="text">13:30 ~ 14:00</p>
    </div>
    <p style="margin-top: 4vh;" class="text">
      政治経済研究部が各々研究した成果を発表します。<br>
      ライトノベルから民主主義まで幅広い分野を発表しますので、ぜひ足を運んでみてください！
    </p>
  </div>
  `;
  window.scrollTo(0, 0);
  };
</script>
</html>